const { getConfig, getQuotesForOrientation, selectQuote } = require("../backend/services/content-service");
const {
  registerEmailAccount,
  loginEmailAccount,
  createGuestSession,
  resolveSession,
  clearSession,
  sanitizeUser,
} = require("../backend/services/auth-service");
const { saveUserState } = require("../backend/services/state-service");

function sendJson(response, statusCode, payload) {
  response.writeHead(statusCode, { "Content-Type": "application/json; charset=utf-8" });
  response.end(JSON.stringify(payload));
}

async function readJsonBody(request) {
  const chunks = [];
  for await (const chunk of request) {
    chunks.push(chunk);
  }
  if (!chunks.length) {
    return {};
  }
  return JSON.parse(Buffer.concat(chunks).toString("utf8"));
}

async function requireSession(request, response) {
  const token = request.headers["x-session-token"];
  const resolved = await resolveSession(token);
  if (!resolved) {
    sendJson(response, 401, { error: "UNAUTHORIZED" });
    return null;
  }
  return resolved;
}

async function handleApiRequest(request, response, requestUrl) {
  if (request.method === "GET" && requestUrl.pathname === "/api/health") {
    sendJson(response, 200, { status: "ok", service: "heart-jar-api" });
    return true;
  }

  if (request.method === "GET" && requestUrl.pathname === "/api/config") {
    sendJson(response, 200, getConfig());
    return true;
  }

  if (request.method === "GET" && requestUrl.pathname === "/api/quotes") {
    const orientation = requestUrl.searchParams.get("orientation") || "";
    sendJson(response, 200, { orientation, quotes: getQuotesForOrientation(orientation) });
    return true;
  }

  if (request.method === "POST" && requestUrl.pathname === "/api/quotes/select") {
    const body = await readJsonBody(request);
    const quote = selectQuote({
      orientation: body.orientation,
      mood: body.mood,
      shownQuoteIds: body.shownQuoteIds,
      feedback: body.feedback,
    });
    sendJson(response, 200, { quote });
    return true;
  }

  if (request.method === "POST" && requestUrl.pathname === "/api/auth/guest") {
    const body = await readJsonBody(request);
    const result = await createGuestSession(body.name || "Guest");
    sendJson(response, 200, result);
    return true;
  }

  if (request.method === "POST" && requestUrl.pathname === "/api/auth/register") {
    const body = await readJsonBody(request);
    try {
      const result = await registerEmailAccount(body);
      sendJson(response, 200, result);
    } catch (error) {
      sendJson(response, 400, { error: error.message });
    }
    return true;
  }

  if (request.method === "POST" && requestUrl.pathname === "/api/auth/login") {
    const body = await readJsonBody(request);
    try {
      const result = await loginEmailAccount(body);
      sendJson(response, 200, result);
    } catch (error) {
      sendJson(response, 400, { error: error.message });
    }
    return true;
  }

  if (request.method === "POST" && requestUrl.pathname === "/api/auth/logout") {
    const token = request.headers["x-session-token"];
    await clearSession(token);
    sendJson(response, 200, { success: true });
    return true;
  }

  if (request.method === "GET" && requestUrl.pathname === "/api/me") {
    const resolved = await requireSession(request, response);
    if (!resolved) {
      return true;
    }
    sendJson(response, 200, {
      user: sanitizeUser(resolved.user),
      state: resolved.user.appState,
    });
    return true;
  }

  if (request.method === "PUT" && requestUrl.pathname === "/api/state") {
    const resolved = await requireSession(request, response);
    if (!resolved) {
      return true;
    }
    const body = await readJsonBody(request);
    const result = await saveUserState(resolved.user.id, body.state);
    sendJson(response, 200, result);
    return true;
  }

  if (request.method === "POST" && requestUrl.pathname === "/api/reflect") {
    const body = await readJsonBody(request);
    sendJson(response, 200, {
      received: true,
      summary: {
        orientation: body.orientation || null,
        mood: body.mood || null,
        preview: typeof body.text === "string" ? body.text.slice(0, 120) : "",
      },
    });
    return true;
  }

  return false;
}

module.exports = {
  handleApiRequest,
};
