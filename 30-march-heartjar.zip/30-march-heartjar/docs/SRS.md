# SOFTWARE REQUIREMENTS SPECIFICATION (SRS)

## HEART JAR
Digital Mental Wellness System with Spiritual Personalization

## 1. Introduction

### 1.1 Purpose
This document describes the functional and non-functional requirements for the HEART JAR application. It is intended for developers, designers, and stakeholders responsible for designing, building, testing, and maintaining the system.

The goal is to establish a precise, implementation-ready understanding of:

- System functionality
- User experience expectations
- Data handling requirements
- Core algorithmic behavior

### 1.2 Scope
HEART JAR is a digital mental wellness application that integrates:

- Mood tracking
- Journaling
- Spiritually personalized quote recommendations

The system delivers emotion-aware and spiritually aligned content based on:

- User-selected spiritual orientation
- Current emotional state, either explicitly selected or inferred from journal text

### 1.3 Definitions
- `Mood Jar`: Core quote delivery system that surfaces personalized quotes
- `Spiritual Orientation`: User-selected belief framework used for personalization
- `Mood Detection Engine`: Algorithm that extracts or infers mood from journal text
- `Recommendation Engine`: System that ranks and selects quotes based on mood, orientation, and feedback history

## 2. Overall Description

### 2.1 Product Perspective
HEART JAR is a standalone hybrid application that supports:

- Offline mode using local storage
- Online mode using cloud synchronization

### 2.2 Product Functions
The system shall provide:

- User authentication through email/password
- Google authentication
- Anonymous access
- Spiritual orientation onboarding
- Mood tracking through manual selection and intelligent mood detection
- Journaling with prompt-based and free-writing modes
- Personalized quote delivery
- Feedback-based quote ranking
- Mood analytics visualization

### 2.3 User Classes
- `Primary Users`: Individuals seeking emotional support, reflection, and spiritually aligned encouragement
- `Secondary Users`: Casual users exploring journaling and mood tracking features

### 2.4 Constraints
The system must:

- Function both offline and online
- Maintain a consistent Regency-themed user experience
- Store personal data securely

## 3. System Features and Requirements

### 3.1 User Authentication Module

#### Functional Requirements
The system shall allow:

- Email/password registration and login
- Google authentication
- Anonymous access

Anonymous users:

- Shall have data stored locally by default
- May optionally convert their local profile into a full account later

### 3.2 Onboarding Module

#### Functional Requirements
The system shall prompt the user to select one spiritual orientation during onboarding.

Available options:

- Hinduism
- Christianity
- Islam
- Buddhism
- Greek Paganism
- Norse Paganism
- Atheism
- Agnosticism
- Taoism
- Sikhism

The system shall:

- Allow the selected orientation to be modified later in settings
- Apply orientation changes only to future recommendations

#### Transition Screen
The system shall display:

- A calming transition message
- A call-to-action button with the label `Enter the Judgement free Ton`

### 3.3 Dashboard Module

#### Functional Requirements
The dashboard shall display:

- Total number of journal entries
- Current quote from the Mood Jar

### 3.4 Mood Tracking Module

#### Functional Requirements
The system shall allow manual mood selection using the following categories:

- Happy
- Sad
- Angry
- Confused
- Numb
- Anxious
- I Don't Know How I Feel

### 3.5 Journaling Module

#### Functional Requirements
The system shall provide two journaling modes:

1. Prompt-based journaling
2. Free writing (`rant mode`)

Prompt-based journaling shall include:

- Five to six predefined prompts
- A custom prompt option

#### Data Handling
Each journal entry shall store:

- Text content
- Timestamp
- Associated mood, either manually selected or inferred

### 3.6 Intelligent Mood Detection Engine

#### Behavior
The system shall analyze journal text and extract emotional indicators.

#### High-Level Algorithm
Input: journal text

1. Tokenize text into words
2. Match words against a mood keyword dictionary
3. Assign weights to detected moods
4. Compute cumulative scores per mood
5. If one dominant mood exists, assign that mood
6. Otherwise assign `I DON'T KNOW HOW I FEEL`

### 3.7 Mood Jar Quote Recommendation Engine

#### Functional Requirements
The system shall retrieve quotes based on:

- Spiritual orientation
- Mood category

#### Quote Data Structure
```text
Quotes {
  orientation: String
  mood: String
  text: String
  ranking_score: Float
}
```

#### Recommendation Algorithm
Input: mood, orientation, user_history

1. Filter quotes by orientation and mood
2. Remove recently shown quotes
3. Remove disliked quotes
4. Rank remaining quotes based on:
   - Like frequency
   - Recency
5. Return the highest ranked quote

### 3.8 Feedback System

#### Functional Requirements
The system shall allow users to:

- Like a quote
- Dislike a quote
- Refresh to retrieve a new quote

The system shall update ranking scores based on this feedback.

### 3.9 Logo-Based Interaction

#### Critical Functional Requirement
The system shall display the HEART JAR logo within the Mood Jar interface and use it as the exclusive trigger for generating a new quote.

#### On-Click Behavior
When the logo is clicked, the system shall:

1. Trigger quote refresh
2. Fetch the next ranked quote
3. Avoid immediate repetition
4. Apply a transition animation

#### Constraint
No separate `Next Quote` button shall exist.

### 3.10 Mood Analytics Module

#### Functional Requirements
The system shall:

- Track mood over time
- Provide daily, weekly, monthly, and yearly views
- Present data as a line graph, bar chart, or both

### 3.11 Data Synchronization

#### Functional Requirements
In offline mode, the system shall:

- Store user data locally

In online mode, the system shall:

- Synchronize user data with a database

## 4. Non-Functional Requirements

### 4.1 Usability
The system shall maintain:

- A Regency-inspired aesthetic
- Elegant typography
- A calm and emotionally supportive interaction flow

### 4.2 Performance
The response time for quote retrieval shall be less than 2 seconds under normal operating conditions.

### 4.3 Security
The system shall:

- Encrypt user journal data
- Secure authentication credentials

### 4.4 Reliability
The system shall ensure:

- Data persistence in offline mode
- Seamless synchronization when connectivity is restored

### 4.5 Scalability
The system shall support:

- Expansion of the quote database
- Addition of new spiritual orientations
- Addition of new moods and classification rules

## 5. High-Level System Architecture

### 5.1 Core Components
- Frontend application layer
- Backend API and business logic layer
- Database layer such as MongoDB or equivalent

### 5.2 High-Level Flow
```text
User Input -> Mood Detection -> Recommendation Engine -> Quote Output
                                       |
                                       v
                                 Feedback Loop
```

## 6. Data Requirements

### 6.1 User Data
- User ID
- Authentication type
- Spiritual orientation

### 6.2 Journal Data
- Entry text
- Timestamp
- Mood

### 6.3 Quote Data
- Orientation
- Mood
- Text
- Ranking score

## 7. UI and UX Requirements

### 7.1 Design Theme
The interface shall reflect:

- A Regency or Bridgerton-inspired visual language
- A soft pastel palette
- A sense of royal elegance

### 7.2 Interaction Style
The system shall use:

- Smooth transitions
- Minimal harsh UI elements
- An emotionally calming experience

### 7.3 Logo Requirement
The HEART JAR logo:

- Must be present in the Mood Jar interface
- Must function as the interactive trigger for quote generation

## 8. Conclusion
HEART JAR is defined as a hybrid emotional wellness and spiritual personalization platform built around:

- Structured application logic
- Intelligent mood-aware algorithms
- A distinct, emotionally supportive UX identity

This SRS is intended to support direct implementation by a development team with minimal ambiguity.
