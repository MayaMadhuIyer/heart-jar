# HEART JAR Implementation Plan

## Suggested Initial Stack
- Frontend: React with TypeScript
- Styling: Tailwind CSS or CSS modules with a custom Regency design system
- Local persistence: IndexedDB or SQLite wrapper for offline-first journaling
- Backend: Node.js with Express or NestJS
- Database: MongoDB
- Auth: Firebase Auth, Clerk, Supabase Auth, or a custom provider
- Charts: Recharts or Chart.js

## Core Modules

### 1. Authentication
- Email/password registration and login
- Google sign-in
- Anonymous session support
- Account upgrade path from anonymous to registered user

### 2. Onboarding and Settings
- Spiritual orientation selection
- Editable preference in settings
- Transition screen with calming copy and CTA

### 3. Dashboard
- Summary cards for total journal entries
- Current quote card
- Quick access to journaling and mood tracking

### 4. Journaling
- Prompt-based journaling flow
- Free-writing mode
- Journal history
- Timestamped entries with mood metadata

### 5. Mood Detection Engine
- Mood keyword dictionary
- Weighted scoring system
- Fallback to `I DON'T KNOW HOW I FEEL`
- Future extension for NLP-based sentiment classification

### 6. Quote Recommendation Engine
- Quote store grouped by orientation and mood
- Ranking logic using:
  - Like frequency
  - Recent exposure filtering
  - Dislike exclusion
- Logo-driven refresh interaction

### 7. Feedback and Learning
- Like action
- Dislike action
- Refresh action
- Ranking score updates and history tracking

### 8. Analytics
- Daily view
- Weekly view
- Monthly view
- Yearly view
- Line and bar chart visualizations

### 9. Offline and Sync
- Local-first data writes
- Sync queue when connectivity returns
- Conflict-handling rules for merged journal and feedback records

## Suggested Milestones

### Milestone 1: Product Foundation
- Set up frontend and backend repos or monorepo
- Create base design tokens for the Regency theme
- Define TypeScript domain models
- Seed quote and prompt datasets

### Milestone 2: Core User Flow
- Build authentication
- Build onboarding
- Build dashboard
- Build journaling flow

### Milestone 3: Personalization Engine
- Implement manual mood selection
- Implement mood inference logic
- Implement recommendation engine
- Implement logo-triggered quote refresh

### Milestone 4: Learning and Analytics
- Add quote feedback actions
- Add ranking updates
- Add mood analytics visualizations

### Milestone 5: Offline and Cloud Sync
- Add local persistence
- Add sync engine
- Add error recovery and retry flows

## Recommended Data Models

### User
```ts
type User = {
  id: string;
  authType: "email" | "google" | "anonymous";
  spiritualOrientation: string;
  createdAt: string;
  updatedAt: string;
};
```

### JournalEntry
```ts
type JournalEntry = {
  id: string;
  userId: string;
  text: string;
  prompt?: string;
  mood: string;
  moodSource: "manual" | "inferred";
  createdAt: string;
};
```

### Quote
```ts
type Quote = {
  id: string;
  orientation: string;
  mood: string;
  text: string;
  rankingScore: number;
};
```

### QuoteFeedback
```ts
type QuoteFeedback = {
  id: string;
  userId: string;
  quoteId: string;
  action: "like" | "dislike" | "refresh";
  createdAt: string;
};
```

## Open Product Decisions
- Whether anonymous users can later sync historical local data into a cloud account automatically
- Whether quotes should be fully curated, partially AI-generated, or both
- Whether mood inference should remain keyword-based in V1 or include an ML/NLP model
- Whether online sync should be real-time or delayed/background-only
- Whether the CTA copy `Enter the Judgement free Ton` should remain exactly as written or be edited for grammar and tone consistency

## Recommended Next Build Step
Start with an MVP that includes:

- Anonymous access
- Spiritual onboarding
- Journaling
- Manual mood tagging
- Basic mood inference
- Quote recommendation
- Quote feedback

This gives the team a complete end-to-end experience before cloud sync and analytics are added.
