const SESSION_KEY = "heart-jar-session-token";

const ORIENTATIONS = [
  "Hinduism",
  "Christianity",
  "Islam",
  "Buddhism",
  "Greek Paganism",
  "Norse Paganism",
  "Atheism",
  "Agnosticism",
  "Taoism",
  "Sikhism",
];

const ONBOARDING_OPTIONS = {
  ageGroup: ["Under 18", "18-24", "25-34", "35-49", "50+"],
  stressLevel: ["Low", "Moderate", "High", "Very high"],
  anxietyLevel: ["Low", "Moderate", "High", "Very high"],
  sleepTroubles: ["Rarely", "Sometimes", "Often", "Every night"],
  emotionalState: ["Happy", "Sad", "Angry", "Confused", "Numb", "Anxious", "I Don't Know How I Feel"],
};

const JOURNAL_PROMPTS = [
  "Choose a prompt",
  "What truth have you been carrying quietly?",
  "What does your body want you to notice today?",
  "What feels unfinished in your heart?",
  "Where did softness show up for you today?",
  "What do you want to release before nightfall?",
];

const MOOD_LIBRARY = [
  { id: "happy", title: "Happy", subtitle: "Feeling positive and uplifted", icon: "Sun", mood: "Happy" },
  { id: "sad", title: "Sad", subtitle: "Feeling low or emotionally heavy", icon: "Rain", mood: "Sad" },
  { id: "angry", title: "Angry", subtitle: "Feeling frustrated or upset", icon: "Flare", mood: "Angry" },
  { id: "confused", title: "Confused", subtitle: "Feeling uncertain or unclear", icon: "Bloom", mood: "Confused" },
  { id: "numb", title: "Numb", subtitle: "Feeling detached or drained", icon: "Moon", mood: "Numb" },
  { id: "anxious", title: "Anxious", subtitle: "Feeling restless or overwhelmed", icon: "Orb", mood: "Anxious" },
  { id: "unknown", title: "I Don't Know How I Feel", subtitle: "Unable to clearly name the feeling", icon: "Mist", mood: "I Don't Know How I Feel" },
];

const RANGE_OPTIONS = ["day", "week", "month", "year"];

const HELPLINES = [
  { region: "United States", name: "988 Suicide & Crisis Lifeline", contact: "Call or text 988", description: "For immediate emotional support in the U.S." },
  { region: "India", name: "Tele-MANAS", contact: "Call 14416 or 1-800-891-4416", description: "Government of India national tele-mental health support service." },
  { region: "India", name: "KIRAN Mental Health Rehabilitation Helpline", contact: "Call 1800-599-0019", description: "24x7 toll-free Government of India mental health rehabilitation helpline." },
  { region: "India", name: "Vandrevala Foundation Mental Health Helpline", contact: "Call or WhatsApp +91 9999 666 555", description: "24x7 free mental health support and counselling helpline." },
  { region: "Emergency", name: "Local emergency services", contact: "Call your local emergency number", description: "Use this if someone is in immediate danger." },
];

const ORIENTATION_QUOTES = {
  Hinduism: { defaultText: "Ahimsa Paramo Dharma; Dharma Himsa Tathaivacha", source: "Mahabharata", note: "Keep only what steadies you. Release the rest with grace." },
  Christianity: { defaultText: "Come to me, all you who are weary and burdened, and I will give you rest.", source: "Matthew 11:28", note: "You are not too much to be met with mercy." },
  Islam: { defaultText: "Indeed, with hardship comes ease.", source: "Qur'an 94:6", note: "Patience is not passivity. It is sacred staying power." },
  Buddhism: { defaultText: "Peace comes from within. Do not seek it without.", source: "Attributed to the Buddha", note: "Return to breath. Return to what is here." },
  "Greek Paganism": { defaultText: "Honor the heart by moving in balance with the sacred order of things.", source: "Contemplative adaptation", note: "Dignity can live beside uncertainty." },
  "Norse Paganism": { defaultText: "Courage is not the absence of storm, but the will to stand through it.", source: "Contemplative adaptation", note: "Rest is not weakness. It is part of endurance." },
  Atheism: { defaultText: "You are allowed to trust your own effort, your own healing, and your own becoming.", source: "Heart Jar reflection", note: "Meaning can be made gently, one honest step at a time." },
  Agnosticism: { defaultText: "Even without certainty, tenderness can still be true.", source: "Heart Jar reflection", note: "Wonder leaves room for healing." },
  Taoism: { defaultText: "Nature does not hurry, yet everything is accomplished.", source: "Lao Tzu", note: "Softness can still be strength." },
  Sikhism: { defaultText: "Where there is forgiveness, there is God.", source: "Guru Granth Sahib", note: "Let truth and kindness stand beside one another." },
};

const MOOD_KEYWORDS = {
  Happy: ["happy", "joy", "grateful", "light", "hope", "relief", "glad"],
  Sad: ["sad", "cry", "hurt", "lonely", "grief", "down", "heavy"],
  Angry: ["angry", "mad", "frustrated", "rage", "resent", "annoyed"],
  Confused: ["confused", "lost", "unsure", "unclear", "stuck", "why"],
  Numb: ["numb", "empty", "hollow", "detached", "blank", "nothing"],
  Anxious: ["anxious", "worried", "panic", "fear", "nervous", "stress"],
};

function initialState() {
  return {
    stage: "welcome",
    accessType: "guest",
    authFormMode: "register",
    authMessage: "",
    activeRoom: "dashboard",
    historyRange: "week",
    user: {
      name: "",
      email: "",
      authType: "guest",
      orientation: "Hinduism",
      ageGroup: "",
      stressLevel: "",
      anxietyLevel: "",
      sleepTroubles: "",
      emotionalState: "",
    },
    currentMood: "I Don't Know How I Feel",
    currentQuoteId: "",
    currentQuoteText: "",
    currentQuoteSource: "",
    journalEntries: [],
    feedback: [],
    shownQuotes: [],
    pendingSyncEvents: [],
    selectedPrompt: "",
    journalMode: "guided",
    analyticsRange: "week",
  };
}

let state = initialState();
let sessionToken = loadSessionToken();
let persistStateTimer = null;

function loadSessionToken() {
  try {
    return localStorage.getItem(SESSION_KEY) || "";
  } catch {
    return "";
  }
}

function setSessionToken(token) {
  sessionToken = token;
  try {
    localStorage.setItem(SESSION_KEY, token);
  } catch {}
}

function clearSessionToken() {
  sessionToken = "";
  try {
    localStorage.removeItem(SESSION_KEY);
  } catch {}
}

function saveState() {
  scheduleRemotePersist();
}

function queueEvent(type, payload) {
  state.pendingSyncEvents.unshift({
    id: crypto.randomUUID(),
    type,
    payload,
    createdAt: new Date().toISOString(),
  });
}

function scheduleRemotePersist() {
  if (!sessionToken || state.stage === "welcome") return;
  clearTimeout(persistStateTimer);
  persistStateTimer = setTimeout(() => {
    HeartJarApi.saveState(sessionToken, state).catch(() => {});
  }, 150);
}

function safeText(value) {
  return String(value ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

function formatDate(value) {
  return new Intl.DateTimeFormat(undefined, {
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
  }).format(new Date(value));
}

function inferMood(text) {
  const words = (text.toLowerCase().match(/[a-z']+/g) || []).join(" ");
  const scores = Object.fromEntries(Object.keys(MOOD_KEYWORDS).map((mood) => [mood, 0]));
  Object.entries(MOOD_KEYWORDS).forEach(([mood, keywords]) => {
    keywords.forEach((keyword) => {
      if (words.includes(keyword)) scores[mood] += 1;
    });
  });
  const ranked = Object.entries(scores).sort((a, b) => b[1] - a[1]);
  if (!ranked[0] || ranked[0][1] === 0) return "I Don't Know How I Feel";
  if (ranked[1] && ranked[0][1] === ranked[1][1]) return "I Don't Know How I Feel";
  return ranked[0][0];
}

async function chooseQuote() {
  const orientation = state.user.orientation || "Hinduism";
  const mood = state.currentMood || "I Don't Know How I Feel";

  try {
    const result = await HeartJarApi.selectQuote({
      orientation,
      mood,
      shownQuoteIds: state.shownQuotes,
      feedback: state.feedback,
    });
    const chosen = result.quote;
    if (!chosen) return;
    state.currentQuoteId = chosen.id;
    state.currentQuoteText = chosen.text;
    state.currentQuoteSource = chosen.source;
    state.shownQuotes.unshift(chosen.id);
    state.shownQuotes = state.shownQuotes.slice(0, 20);
  } catch {
    const fallback = ORIENTATION_QUOTES[orientation] || ORIENTATION_QUOTES.Hinduism;
    state.currentQuoteId = "";
    state.currentQuoteText = fallback.defaultText;
    state.currentQuoteSource = fallback.source;
  }
}

function currentMoodTitle() {
  const entry = MOOD_LIBRARY.find((item) => item.mood === state.currentMood);
  return entry ? entry.title : "I Don't Know How I Feel";
}

function onboardingComplete() {
  const user = state.user;
  return Boolean(user.name && user.ageGroup && user.stressLevel && user.anxietyLevel && user.sleepTroubles && user.emotionalState && user.orientation);
}

function filteredEntries(range) {
  const now = new Date();
  return state.journalEntries.filter((entry) => {
    const date = new Date(entry.createdAt);
    const diff = now - date;
    if (range === "day") return diff <= 24 * 60 * 60 * 1000;
    if (range === "week") return diff <= 7 * 24 * 60 * 60 * 1000;
    if (range === "month") return diff <= 31 * 24 * 60 * 60 * 1000;
    return diff <= 365 * 24 * 60 * 60 * 1000;
  });
}

function displayMoodName(mood) {
  return (MOOD_LIBRARY.find((item) => item.mood === mood) || { title: mood }).title;
}

function shorten(text, max) {
  if (!text) return "";
  return text.length > max ? `${text.slice(0, max - 1)}...` : text;
}

function capitalize(text) {
  return text.charAt(0).toUpperCase() + text.slice(1);
}

function moodFromOnboarding(label) {
  const item = MOOD_LIBRARY.find((entry) => entry.title === label);
  return item ? item.mood : "I Don't Know How I Feel";
}

function render() {
  const app = document.getElementById("app");
  if (state.stage === "welcome") app.innerHTML = renderWelcome();
  else if (state.stage === "onboarding") app.innerHTML = renderOnboarding();
  else if (state.stage === "zen") app.innerHTML = renderZen();
  else {
    app.innerHTML = renderMain();
    drawMoodPortrait();
  }
  saveState();
}

function renderWelcome() {
  const isEmail = state.accessType === "email";
  const isLogin = state.authFormMode === "login";
  return `
    <section class="screen-center">
      <div>
        <article class="welcome-card">
          <section class="welcome-visual">
            <div class="jar-frame">
              <img src="assets/logo.png" alt="Heart Jar" />
            </div>
          </section>
          <section class="welcome-panel">
            <div class="form-box">
              <p class="kicker">Welcome</p>
              <h1 class="display-title">HEART JAR</h1>
              <p class="lead">A private drawing room for your moods, memories, and gentle reflections.</p>
              <div class="access-row">
                ${["guest", "email"]
                  .map(
                    (type) => `<button class="chip-btn ${state.accessType === type ? "active" : ""}" data-access="${type}" type="button">${
                      type === "guest" ? "Login as Guest" : "Use Email"
                    }</button>`,
                  )
                  .join("")}
              </div>
              ${
                isEmail
                  ? `
                    <div class="access-row">
                      <button class="chip-btn ${isLogin ? "active" : ""}" data-auth-mode="login" type="button">Sign in</button>
                      <button class="chip-btn ${!isLogin ? "active" : ""}" data-auth-mode="register" type="button">Create account</button>
                    </div>
                  `
                  : ""
              }
              <div class="field">
                <label for="nameInput">${isEmail && isLogin ? "Display name (optional for sign in)" : "What name shall we call you by?"}</label>
                <input id="nameInput" class="text-input" type="text" placeholder="${isEmail && isLogin ? "Enter your name or leave blank" : "Enter your name"}" value="${safeText(state.user.name)}" />
              </div>
              ${
                isEmail
                  ? `
                    <div class="field">
                      <label for="emailInput">Email</label>
                      <input id="emailInput" class="text-input" type="email" placeholder="name@example.com" value="${safeText(state.user.email)}" />
                    </div>
                    <div class="field">
                      <label for="passwordInput">Password</label>
                      <input id="passwordInput" class="text-input" type="password" placeholder="${isLogin ? "Enter your password" : "Create a password"}" />
                    </div>
                  `
                  : ""
              }
              ${state.authMessage ? `<p class="muted" style="color:#9a646f;">${safeText(state.authMessage)}</p>` : ""}
              <button id="continueWelcomeBtn" class="primary-btn" type="button">Continue to onboarding</button>
            </div>
          </section>
        </article>
        <div class="footer-note">HEART JAR - Conceptualized, Designed, and Created by Mayam &lt;3 2026</div>
      </div>
    </section>
  `;
}

function renderSelectField(key, label, options) {
  return `
    <div class="field">
      <label for="${key}">${label}</label>
      <select id="${key}" class="select-input" data-profile="${key}">
        <option value="">Select an option</option>
        ${options
          .map((option) => `<option value="${safeText(option)}" ${state.user[key] === option ? "selected" : ""}>${safeText(option)}</option>`)
          .join("")}
      </select>
    </div>
  `;
}

function renderOnboarding() {
  return `
    <section class="screen-center">
      <article class="screen-card">
        <p class="kicker">Onboarding</p>
        <h1>Tell HEART JAR a little about the season you are in</h1>
        <div class="room-subtle" style="border-top:1px solid rgba(224,210,195,.72); margin-top:18px; padding-top:22px;">
          <div class="split-grid">
            ${renderSelectField("ageGroup", "Age group", ONBOARDING_OPTIONS.ageGroup)}
            ${renderSelectField("stressLevel", "Stress level", ONBOARDING_OPTIONS.stressLevel)}
            ${renderSelectField("anxietyLevel", "Anxiety level", ONBOARDING_OPTIONS.anxietyLevel)}
            ${renderSelectField("sleepTroubles", "Sleep troubles", ONBOARDING_OPTIONS.sleepTroubles)}
            ${renderSelectField("emotionalState", "Emotional state", ONBOARDING_OPTIONS.emotionalState)}
            ${renderSelectField("orientation", "Spiritual orientation", ORIENTATIONS)}
          </div>
          <button id="continueOnboardingBtn" class="primary-btn" type="button" ${onboardingComplete() ? "" : "disabled"}>Continue to the zen screen</button>
        </div>
      </article>
    </section>
  `;
}

function renderZen() {
  return `
    <section class="screen-center">
      <article class="screen-card zen-card">
        <p class="kicker">Zen Transition</p>
        <h1>Don't worry, you're safe and heard.</h1>
        <p class="subtle">Take a breath. This next room is prepared with softness, dignity, and a quiet place for truth.</p>
        <button id="enterRoomBtn" class="primary-btn zen-cta" type="button">Enter the judgement free ton</button>
      </article>
    </section>
  `;
}

function renderMain() {
  return `
    <div class="app-shell">
      ${renderNav()}
      <section class="room-stack">
        ${state.activeRoom === "dashboard" ? renderDashboard() : ""}
        ${state.activeRoom === "mood" ? renderMoodTracking() : ""}
        ${state.activeRoom === "journal" ? renderJournal() : ""}
        ${state.activeRoom === "jar" ? renderMoodJar() : ""}
        ${state.activeRoom === "help" ? renderHelp() : ""}
        ${state.activeRoom === "settings" ? renderSettings() : ""}
      </section>
      <div class="footer-row">
        <div class="footer-note">HEART JAR - Conceptualized, Designed, and Created by Mayam &lt;3 2026</div>
        ${(state.activeRoom === "help" || state.activeRoom === "settings") ? '<button id="logoutBtn" class="logout-btn" type="button">Log out</button>' : ""}
      </div>
    </div>
  `;
}

function renderNav() {
  const navItems = [
    ["dashboard", "Dashboard"],
    ["mood", "Mood Tracking"],
    ["journal", "Journal"],
    ["jar", "Mood Jar"],
    ["help", "Helplines"],
  ];

  return `
    <header class="nav-shell">
      <nav class="nav-list">
        ${navItems.map(([id, label]) => `<button class="nav-btn ${state.activeRoom === id ? "active" : ""}" data-room="${id}" type="button">${label}</button>`).join("")}
      </nav>
      <button class="brand-badge" id="settingsBadge" type="button">
        <img src="assets/logo.png" alt="Heart Jar seal" />
        <span class="brand-copy">
          <span>Private Journal</span>
          <span>Heart Jar</span>
        </span>
      </button>
    </header>
  `;
}

function renderDashboard() {
  return `
    <article class="room-card">
      <header class="room-header">
        <p class="room-label">Dashboard</p>
      </header>
      <div class="dashboard-grid">
        <section class="dashboard-copy">
          <h2>Welcome back, ${safeText((state.user.name || "Mayam").toUpperCase())}.</h2>
          <p class="lead">Your private sanctuary now opens into dedicated rooms for mood tracking, journaling, gentle quotes, and support.</p>
          <div class="stats-row">
            <article class="mini-card"><h3>Mood entries</h3><div class="mini-value">${state.journalEntries.length}</div></article>
            <article class="mini-card"><h3>Current quote</h3><div class="mini-value">${safeText(shorten(state.currentQuoteText || ORIENTATION_QUOTES[state.user.orientation].defaultText, 60))}</div></article>
            <article class="mini-card"><h3>Emotional state</h3><div class="mini-value">${safeText(currentMoodTitle())}</div></article>
          </div>
        </section>
        <aside class="note-box">
          <div class="note-pill">${safeText(state.user.orientation)}</div>
          <div class="quote-note">
            <p class="kicker" style="margin-bottom:10px;">Drawing Room Note</p>
            <p>${safeText(ORIENTATION_QUOTES[state.user.orientation].note)}</p>
          </div>
        </aside>
      </div>
    </article>
  `;
}

function renderMoodTracking() {
  const entries = filteredEntries(state.historyRange);
  return `
    <article class="room-card">
      <header class="room-header">
        <p class="room-label">Mood Tracking</p>
        <h2>How does your heart feel today?</h2>
      </header>
      <div class="mood-grid">
        ${MOOD_LIBRARY.map(
          (item) => `
            <button class="mood-tile ${state.currentMood === item.mood ? "active" : ""}" data-mood="${safeText(item.mood)}" type="button">
              <div class="mood-icon">${item.icon}</div>
              <h3>${safeText(item.title)}</h3>
              <p>${safeText(item.subtitle)}</p>
            </button>
          `,
        ).join("")}
      </div>
    </article>
    <article class="room-card">
      <header class="room-header">
        <p class="room-label">History</p>
        <h2>A record of your recent feelings</h2>
      </header>
      <div class="history-controls">
        ${RANGE_OPTIONS.map((range) => `<button class="range-btn ${state.historyRange === range ? "active" : ""}" data-range="${range}" type="button">${capitalize(range)}</button>`).join("")}
      </div>
      <div class="history-box">
        ${
          entries.length
            ? `<div class="entry-list">${entries
                .slice(0, 6)
                .map((entry) => `<article class="entry-row"><div class="entry-meta"><span>${safeText(displayMoodName(entry.mood))}</span><span>${safeText(formatDate(entry.createdAt))}</span></div><div>${safeText(shorten(entry.text, 140))}</div></article>`)
                .join("")}</div>`
            : '<p class="muted">No mood entries in this time window just yet.</p>'
        }
      </div>
    </article>
  `;
}

function renderJournal() {
  return `
    <article class="room-card">
      <header class="room-header">
        <p class="room-label">Journaling</p>
        <h2>Write in your private letter-book</h2>
      </header>
      <div class="journal-mode-switch">
        <button class="journal-mode-card ${state.journalMode === "guided" ? "active" : ""}" data-journal-mode="guided" type="button">
          <div class="journal-mode-title">Guided Writing</div>
          <div class="journal-mode-copy">Follow a thoughtful prompt when you want structure and a softer starting point.</div>
        </button>
        <button class="journal-mode-card ${state.journalMode === "rant" ? "active" : ""}" data-journal-mode="rant" type="button">
          <div class="journal-mode-title">Rant Mode</div>
          <div class="journal-mode-copy">Just write. No structure, no judgment, and no need to soften the truth.</div>
        </button>
      </div>
      <div class="form-grid">
        <form class="journal-form" id="journalForm">
          ${
            state.journalMode === "guided"
              ? `
                <div class="field">
                  <label for="promptSelect">Prompt</label>
                  <select id="promptSelect" class="select-input">
                    ${JOURNAL_PROMPTS.map((prompt) => `<option value="${safeText(prompt)}" ${state.selectedPrompt === prompt ? "selected" : ""}>${safeText(prompt)}</option>`).join("")}
                  </select>
                </div>
              `
              : '<div class="mode-banner">Rant Mode is on. This page is yours to write in freely.</div>'
          }
          <div class="field">
            <label for="entryTitle">Entry title</label>
            <input id="entryTitle" class="text-input" type="text" placeholder="${state.journalMode === "guided" ? "A quiet note to yourself" : "Say it as it is"}" />
          </div>
          <div class="field">
            <label for="associatedMood">Associated mood</label>
            <select id="associatedMood" class="select-input">
              <option value="">No associated mood</option>
              ${MOOD_LIBRARY.map((item) => `<option value="${safeText(item.mood)}">${safeText(item.title)}</option>`).join("")}
            </select>
          </div>
          <div class="field">
            <label for="entryText">Journal entry</label>
            <textarea id="entryText" class="text-area" placeholder="Write freely. This space is for truth, softness, and relief."></textarea>
          </div>
          <button class="primary-btn" type="submit">Save entry</button>
        </form>
        <section>
          ${
            state.journalEntries.length
              ? `<div class="entry-list">${state.journalEntries
                  .slice(0, 6)
                  .map(
                    (entry) => `
                      <article class="entry-row">
                        <div class="entry-meta"><span>${safeText(entry.title || "Untitled letter")}</span><span>${safeText(formatDate(entry.createdAt))}</span></div>
                        <div class="muted" style="margin-bottom:8px;">${safeText(displayMoodName(entry.mood))}</div>
                        <div>${safeText(shorten(entry.text, 180))}</div>
                        <div class="entry-actions">
                          <button class="entry-delete-btn" data-delete-entry="${safeText(entry.id)}" type="button">Delete</button>
                        </div>
                      </article>
                    `,
                  )
                  .join("")}</div>`
              : '<div class="empty-journal">No letters in your journal yet.</div>'
          }
        </section>
      </div>
    </article>
  `;
}

function renderMoodJar() {
  return `
    <article class="room-card">
      <header class="room-header">
        <p class="room-label">Mood Jar</p>
        <h2>Draw a comforting thought</h2>
      </header>
      <div class="jar-grid">
        <div class="jar-display">
          <button id="jarRefreshBtn" class="jar-button" type="button" aria-label="Tap the jar for a new quote">
            <img src="assets/logo.png" alt="Heart Jar" />
          </button>
          <div class="tap-note">Tap the jar</div>
          <div class="action-row">
            <button class="secondary-pill" data-feedback="like" type="button">Like</button>
            <button class="secondary-pill" data-feedback="dislike" type="button">Dislike</button>
          </div>
        </div>
        <article class="quote-display">
          <p class="room-label">${safeText(state.user.orientation)}</p>
          <blockquote>"${safeText(state.currentQuoteText || ORIENTATION_QUOTES[state.user.orientation].defaultText)}"</blockquote>
          <div class="quote-source">${safeText(state.currentQuoteSource || ORIENTATION_QUOTES[state.user.orientation].source)}</div>
        </article>
      </div>
    </article>
  `;
}

function renderHelp() {
  return `
    <article class="room-card">
      <header class="room-header">
        <p class="room-label">Support</p>
        <h2>Keep practical help within easy reach</h2>
      </header>
      <div class="support-grid">
        <div class="muted" style="font-size:1.1rem;">This room holds reminders, helplines, and next-step support so care is close by whenever reflection needs reinforcement.</div>
        <article class="quote-display">
          <p class="room-label">Gentle Reminder</p>
          <blockquote style="font-size:2rem;">Reaching out for help is not an interruption. It is care in action.</blockquote>
        </article>
      </div>
    </article>
    <article class="room-card">
      <header class="room-header">
        <p class="room-label">Help & Support</p>
        <h2>A gentle reminder and practical help</h2>
      </header>
      <div class="helplines-grid">
        <article class="portrait-card">
          <p class="muted" style="font-size:1.1rem;">HEART JAR is a reflective wellness companion, not a medical or crisis intervention service. If you feel unsafe, at risk, or unable to cope, please contact emergency services or a licensed mental health professional right away.</p>
          <p class="muted" style="font-size:1.1rem; margin-top:24px;">If your distress feels intense, ongoing, or unsafe, reaching out to a mental health professional is a wise and brave next step.</p>
          <p class="connection-note">Offline-first mode is ${navigator.onLine ? "available online" : "active offline"}. Pending sync events: ${state.pendingSyncEvents.length}.</p>
        </article>
        <section class="helplines-list">
          ${HELPLINES.map((item) => `<article class="helpline-card"><p class="room-label">${safeText(item.region)}</p><h3>${safeText(item.name)}</h3><p>${safeText(item.contact)}</p><p>${safeText(item.description)}</p></article>`).join("")}
        </section>
      </div>
    </article>
  `;
}

function renderSettings() {
  return `
    <article class="room-card">
      <header class="room-header">
        <p class="room-label">Mood Summary</p>
        <h2>Your mood portrait</h2>
      </header>
      <div class="summary-grid">
        <article class="summary-card">
          ${state.journalEntries.length ? '<canvas id="moodPortraitCanvas" width="1000" height="260"></canvas>' : '<p class="muted">Add a few mood entries and your pie chart will appear here.</p>'}
        </article>
      </div>
    </article>
    <article class="room-card">
      <header class="room-header">
        <p class="room-label">Personalization</p>
        <h2>Change spiritual orientation</h2>
      </header>
      <div class="settings-row">
        <div class="field" style="margin-top:0;">
          <label for="settingsOrientation">Spiritual orientation</label>
          <select id="settingsOrientation" class="select-input">
            ${ORIENTATIONS.map((orientation) => `<option value="${safeText(orientation)}" ${state.user.orientation === orientation ? "selected" : ""}>${safeText(orientation)}</option>`).join("")}
          </select>
        </div>
        <button id="saveOrientationBtn" class="primary-btn" type="button">Save orientation</button>
      </div>
      <div class="action-row">
        <button id="exportBtn" class="secondary-pill" type="button">Export data snapshot</button>
      </div>
    </article>
  `;
}

function drawMoodPortrait() {
  const canvas = document.getElementById("moodPortraitCanvas");
  if (!canvas || !state.journalEntries.length) return;
  const ctx = canvas.getContext("2d");
  const entries = filteredEntries(state.analyticsRange);
  const total = Math.max(entries.length, 1);
  const colors = ["#d8b36d", "#7f4d5f", "#d7a3ad", "#c7bddb", "#e5c7b8", "#b39ab1"];
  const counts = MOOD_LIBRARY.map((item) => ({
    label: item.title,
    count: entries.filter((entry) => entry.mood === item.mood).length,
  })).filter((item) => item.count > 0);

  ctx.clearRect(0, 0, canvas.width, canvas.height);
  if (!counts.length) {
    ctx.fillStyle = "#b79295";
    ctx.font = '28px "Palatino Linotype"';
    ctx.fillText("Add a few mood entries and your portrait will appear here.", 40, 120);
    return;
  }

  const centerX = 180;
  const centerY = 130;
  const radius = 86;
  let start = -Math.PI / 2;
  counts.forEach((item, index) => {
    const angle = (item.count / total) * Math.PI * 2;
    ctx.beginPath();
    ctx.moveTo(centerX, centerY);
    ctx.arc(centerX, centerY, radius, start, start + angle);
    ctx.closePath();
    ctx.fillStyle = colors[index % colors.length];
    ctx.fill();
    start += angle;
  });

  ctx.beginPath();
  ctx.fillStyle = "#fff8f3";
  ctx.arc(centerX, centerY, 42, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = "#7f5663";
  ctx.font = '24px "Palatino Linotype"';
  ctx.fillText("Mood portrait", 320, 58);
  ctx.font = '18px "Palatino Linotype"';
  counts.forEach((item, index) => {
    const y = 100 + index * 28;
    ctx.fillStyle = colors[index % colors.length];
    ctx.fillRect(320, y - 12, 14, 14);
    ctx.fillStyle = "#9e7a7d";
    ctx.fillText(`${item.label}: ${item.count}`, 346, y);
  });
}

function exportSnapshot() {
  const blob = new Blob([JSON.stringify(state, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `heart-jar-${Date.now()}.json`;
  link.click();
  URL.revokeObjectURL(url);
}

async function loginAsGuest(name) {
  const result = await HeartJarApi.loginGuest(name);
  setSessionToken(result.token);
  state = {
    ...initialState(),
    ...(result.state || {}),
    accessType: "guest",
    stage: result.state?.stage || "onboarding",
    user: {
      ...initialState().user,
      ...(result.state?.user || {}),
      ...result.user,
      name,
      authType: "guest",
    },
  };
  queueEvent("guest_session_started", { name });
}

async function loginWithEmail({ name, email, password, mode }) {
  try {
    const result =
      mode === "login"
        ? await HeartJarApi.loginEmail({ email, password })
        : await HeartJarApi.registerEmail({
            name,
            email,
            password,
            state: {
              ...initialState(),
              accessType: "email",
              stage: "onboarding",
              user: {
                ...initialState().user,
                name,
                email: email.trim().toLowerCase(),
                authType: "email",
              },
            },
          });

    setSessionToken(result.token);
    state = {
      ...initialState(),
      ...(result.state || {}),
      accessType: "email",
      authFormMode: mode,
      authMessage: "",
      user: {
        ...initialState().user,
        ...(result.state?.user || {}),
        ...result.user,
        name: result.user.name || name,
        email: result.user.email || email.trim().toLowerCase(),
        authType: "email",
      },
    };
    queueEvent(mode === "login" ? "email_login" : "email_account_created", {
      email: result.user.email || email.trim().toLowerCase(),
    });
    return true;
  } catch (error) {
    if (error.message === "ACCOUNT_NOT_FOUND") {
      state.authMessage = "No account was found for that email.";
    } else if (error.message === "INVALID_PASSWORD") {
      state.authMessage = "That password does not match this account.";
    } else if (error.message === "ACCOUNT_EXISTS") {
      state.authMessage = "An account with that email already exists. Try signing in instead.";
    } else {
      state.authMessage = "We could not complete that sign-in right now.";
    }
    return false;
  }
}

document.addEventListener("click", async (event) => {
  const target = event.target.closest("button");
  if (!target) return;

  if (target.dataset.access) {
    state.accessType = target.dataset.access;
    state.authMessage = "";
    render();
    return;
  }

  if (target.dataset.authMode) {
    state.authFormMode = target.dataset.authMode;
    state.authMessage = "";
    render();
    return;
  }

  if (target.id === "continueWelcomeBtn") {
    const value = document.getElementById("nameInput").value.trim();
    const isEmail = state.accessType === "email";
    if (!isEmail && !value) {
      state.authMessage = "Please enter your name before continuing.";
      render();
      return;
    }

    if (!isEmail) {
      await loginAsGuest(value);
      render();
      return;
    }

    const email = document.getElementById("emailInput").value.trim();
    const password = document.getElementById("passwordInput").value;
    if (!email || !password) {
      state.authMessage = "Please enter your email and password.";
      render();
      return;
    }
    if (password.length < 6) {
      state.authMessage = "Please use a password with at least 6 characters.";
      render();
      return;
    }
    if (state.authFormMode === "register" && !value) {
      state.authMessage = "Please enter your name before creating an account.";
      render();
      return;
    }
    if (!(await loginWithEmail({ name: value || "Heart Jar Guest", email, password, mode: state.authFormMode }))) {
      render();
      return;
    }
    render();
    return;
  }

  if (target.id === "continueOnboardingBtn" && onboardingComplete()) {
    state.stage = "zen";
    state.currentMood = moodFromOnboarding(state.user.emotionalState);
    await chooseQuote();
    queueEvent("onboarding_complete", { orientation: state.user.orientation });
    render();
    return;
  }

  if (target.id === "enterRoomBtn") {
    state.stage = "main";
    state.activeRoom = "dashboard";
    render();
    return;
  }

  if (target.dataset.room) {
    state.activeRoom = target.dataset.room;
    render();
    return;
  }

  if (target.id === "settingsBadge") {
    state.activeRoom = "settings";
    render();
    return;
  }

  if (target.dataset.mood) {
    state.currentMood = target.dataset.mood;
    await chooseQuote();
    queueEvent("mood_selected", { mood: state.currentMood });
    render();
    return;
  }

  if (target.dataset.range) {
    state.historyRange = target.dataset.range;
    state.analyticsRange = target.dataset.range;
    render();
    return;
  }

  if (target.dataset.journalMode) {
    state.journalMode = target.dataset.journalMode;
    if (state.journalMode === "rant") {
      state.selectedPrompt = "";
    }
    render();
    return;
  }

  if (target.id === "jarRefreshBtn") {
    target.classList.remove("spin");
    void target.offsetWidth;
    target.classList.add("spin");
    await chooseQuote();
    queueEvent("quote_refresh", { quoteId: state.currentQuoteId });
    setTimeout(render, 200);
    return;
  }

  if (target.dataset.feedback) {
    const previousQuoteId = state.currentQuoteId;
    state.feedback.unshift({
      id: crypto.randomUUID(),
      quoteId: previousQuoteId,
      type: target.dataset.feedback,
      createdAt: new Date().toISOString(),
    });
    if (target.dataset.feedback === "dislike") await chooseQuote();
    queueEvent("quote_feedback", { quoteId: previousQuoteId, type: target.dataset.feedback });
    render();
    return;
  }

  if (target.dataset.deleteEntry) {
    state.journalEntries = state.journalEntries.filter((entry) => entry.id !== target.dataset.deleteEntry);
    queueEvent("journal_entry_deleted", { entryId: target.dataset.deleteEntry });
    render();
    return;
  }

  if (target.id === "saveOrientationBtn") {
    state.user.orientation = document.getElementById("settingsOrientation").value;
    await chooseQuote();
    queueEvent("orientation_saved", { orientation: state.user.orientation });
    render();
    return;
  }

  if (target.id === "exportBtn") {
    exportSnapshot();
    return;
  }

  if (target.id === "logoutBtn") {
    try {
      if (sessionToken) {
        await HeartJarApi.logout(sessionToken);
      }
    } catch {}
    clearSessionToken();
    state = initialState();
    render();
  }
});

document.addEventListener("change", (event) => {
  const target = event.target;
  if (!(target instanceof HTMLElement)) return;

  if (target.matches("[data-profile]")) {
    state.user[target.dataset.profile] = target.value;
    render();
    return;
  }

  if (target.id === "promptSelect") {
    state.selectedPrompt = target.value === "Choose a prompt" ? "" : target.value;
    saveState();
  }
});

document.addEventListener("submit", async (event) => {
  if (event.target.id !== "journalForm") return;
  event.preventDefault();
  const title = document.getElementById("entryTitle").value.trim();
  const text = document.getElementById("entryText").value.trim();
  const mood = document.getElementById("associatedMood").value || inferMood(text);
  const promptSelect = document.getElementById("promptSelect");
  const prompt = promptSelect ? promptSelect.value : "";
  if (!text) return;

  state.journalEntries.unshift({
    id: crypto.randomUUID(),
    title,
    text,
    prompt: prompt === "Choose a prompt" ? "" : prompt,
    mode: state.journalMode,
    mood,
    createdAt: new Date().toISOString(),
  });
  state.currentMood = mood;
  await chooseQuote();
  queueEvent("journal_entry_saved", { mood, title: title || "Untitled letter" });
  render();
});

window.addEventListener("online", render);
window.addEventListener("offline", render);

async function bootstrap() {
  if (!state.currentQuoteText) await chooseQuote();

  if (!sessionToken) {
    render();
    return;
  }

  try {
    const session = await HeartJarApi.getSession(sessionToken);
    state = {
      ...initialState(),
      ...(session.state || {}),
      accessType: session.user.authType === "email" ? "email" : "guest",
      user: {
        ...initialState().user,
        ...(session.state?.user || {}),
        ...session.user,
      },
    };
  } catch {
    clearSessionToken();
    state = initialState();
  }

  if (!state.currentQuoteText) await chooseQuote();
  render();
}

bootstrap();
