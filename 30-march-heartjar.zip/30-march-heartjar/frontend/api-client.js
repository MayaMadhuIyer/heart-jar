(function () {
  function resolveApiBase() {
    const { protocol, hostname, port } = window.location;
    if ((hostname === "localhost" || hostname === "127.0.0.1") && port && port !== "4000") {
      return `${protocol}//${hostname}:4000/api`;
    }
    return "/api";
  }

  const API_BASE = resolveApiBase();

  async function request(path, options = {}) {
    const response = await fetch(`${API_BASE}${path}`, {
      ...options,
      headers: {
        ...(options.headers || {}),
      },
    });

    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      const error = new Error(data.error || "Request failed");
      error.payload = data;
      throw error;
    }
    return data;
  }

  window.HeartJarApi = {
    getConfig() {
      return request("/config");
    },
    selectQuote(payload) {
      return request("/quotes/select", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      });
    },
    getSession(token) {
      return request("/me", {
        headers: {
          "x-session-token": token,
        },
      });
    },
    loginGuest(name) {
      return request("/auth/guest", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ name }),
      });
    },
    registerEmail(payload) {
      return request("/auth/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      });
    },
    loginEmail(payload) {
      return request("/auth/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      });
    },
    logout(token) {
      return request("/auth/logout", {
        method: "POST",
        headers: {
          "x-session-token": token,
        },
      });
    },
    saveState(token, state) {
      return request("/state", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          "x-session-token": token,
        },
        body: JSON.stringify({ state }),
      });
    },
  };
})();
