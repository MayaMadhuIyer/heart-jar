# Heart Jar

Heart Jar is a structured web application with separate frontend, backend, and API layers.

## Project Structure

```text
heart-jar/
  frontend/
    index.html
    styles.css
    app.js
    api-client.js
    assets/
  backend/
    package.json
    server.js
    services/
    storage/
    utils/
  api/
    index.js
  docs/
    SRS.md
    implementation-plan.md
  README.md
```

## What Lives Where

- `frontend/`
  The full user interface for Heart Jar, including the welcome flow, onboarding, dashboard, mood tracking, journaling, mood jar, helplines, settings, and API client.

- `backend/`
  A Node server plus service, storage, and utility layers. It serves the frontend and exposes API routes under `/api/*`.

- `api/`
  API route handling for auth, session loading, state persistence, config, quotes, health checks, and future backend features.

- `docs/`
  Product requirements and implementation planning documents.

## Current Features

- Guest login and local email account login
- Backend-backed sessions
- File-backed user/account persistence
- Spiritual onboarding
- Zen transition screen
- Dashboard and room-based navigation
- Mood tracking
- Journaling with saved local entries
- Mood-based quote recommendations
- Jar-only quote refresh interaction
- Helplines and support room
- Mood portrait/settings view

## Architecture Notes

- The frontend is a static client served by the backend.
- The backend uses built-in Node modules only, so it runs without package installs beyond `npm start`.
- API-backed auth now handles:
  - guest session creation
  - email account registration
  - email sign-in
  - session restore
  - logout
- Persisted application state is stored server-side in:
  [backend/storage/app-data.json](C:\Users\Maya%20Madhu%20Iyer\Desktop\30-march-heartjar\backend\storage\app-data.json)

## Run The App

From the `backend` folder:

```powershell
cd backend
npm start
```

Then open:

```text
http://localhost:3000
```

## API Endpoints

- `GET /api/health`
  Basic health check

- `GET /api/config`
  Returns orientations and helplines

- `GET /api/quotes?orientation=Hinduism`
  Returns quotes for a given orientation

- `POST /api/auth/guest`
  Creates a guest session

- `POST /api/auth/register`
  Creates an email account and session

- `POST /api/auth/login`
  Signs in an email account

- `POST /api/auth/logout`
  Ends the current session

- `GET /api/me`
  Returns the authenticated user and saved app state

- `PUT /api/state`
  Saves the full current application state for the authenticated user

- `POST /api/reflect`
  Accepts a reflection payload and returns a lightweight summary response

## Notes

- The browser now stores only the session token; account/app state is persisted by the backend.
- The backend is intentionally dependency-light so the app stays runnable in this environment.
- The next natural upgrade would be moving file-backed storage to a database and replacing the custom auth/session implementation with a production auth provider.
