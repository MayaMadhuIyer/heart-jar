const fs = require("fs/promises");
const path = require("path");

const DATA_FILE = path.resolve(__dirname, "app-data.json");

async function readData() {
  const raw = await fs.readFile(DATA_FILE, "utf8");
  return JSON.parse(raw);
}

async function writeData(data) {
  await fs.writeFile(DATA_FILE, JSON.stringify(data, null, 2), "utf8");
}

async function updateData(mutator) {
  const current = await readData();
  const next = await mutator(current);
  await writeData(next);
  return next;
}

module.exports = {
  readData,
  writeData,
  updateData,
};
