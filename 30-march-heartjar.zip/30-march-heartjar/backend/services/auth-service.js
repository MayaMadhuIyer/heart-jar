const { readData, updateData } = require("../storage/data-store");
const { createId, createSessionToken, hashPassword } = require("../utils/security");

function sanitizeUser(user) {
  return {
    id: user.id,
    name: user.name,
    email: user.email || "",
    authType: user.authType,
    createdAt: user.createdAt,
    updatedAt: user.updatedAt,
  };
}

async function createGuestSession(name) {
  const now = new Date().toISOString();
  const userId = createId("guest");
  const token = createSessionToken();

  await updateData((data) => {
    data.users.push({
      id: userId,
      name,
      email: "",
      authType: "guest",
      passwordHash: "",
      appState: null,
      createdAt: now,
      updatedAt: now,
    });
    data.sessions.push({
      token,
      userId,
      createdAt: now,
      updatedAt: now,
    });
    return data;
  });

  const latest = await readData();
  const user = latest.users.find((item) => item.id === userId);
  return { token, user: sanitizeUser(user), state: user.appState };
}

async function registerEmailAccount({ name, email, password, state }) {
  const normalizedEmail = String(email).trim().toLowerCase();
  const now = new Date().toISOString();
  const token = createSessionToken();
  const passwordHash = hashPassword(password);

  const updated = await updateData((data) => {
    const exists = data.users.some((user) => user.email.toLowerCase() === normalizedEmail);
    if (exists) {
      throw new Error("ACCOUNT_EXISTS");
    }

    const userId = createId("user");
    data.users.push({
      id: userId,
      name,
      email: normalizedEmail,
      authType: "email",
      passwordHash,
      appState: state || null,
      createdAt: now,
      updatedAt: now,
    });
    data.sessions.push({
      token,
      userId,
      createdAt: now,
      updatedAt: now,
    });
    return data;
  });

  const user = updated.users.find((item) => item.email === normalizedEmail);
  return { token, user: sanitizeUser(user), state: user.appState };
}

async function loginEmailAccount({ email, password }) {
  const normalizedEmail = String(email).trim().toLowerCase();
  const now = new Date().toISOString();
  const token = createSessionToken();
  const passwordHash = hashPassword(password);

  const updated = await updateData((data) => {
    const user = data.users.find((item) => item.email.toLowerCase() === normalizedEmail);
    if (!user) {
      throw new Error("ACCOUNT_NOT_FOUND");
    }
    if (user.passwordHash !== passwordHash) {
      throw new Error("INVALID_PASSWORD");
    }

    data.sessions.push({
      token,
      userId: user.id,
      createdAt: now,
      updatedAt: now,
    });
    user.updatedAt = now;
    return data;
  });

  const user = updated.users.find((item) => item.email.toLowerCase() === normalizedEmail);
  return { token, user: sanitizeUser(user), state: user.appState };
}

async function resolveSession(token) {
  if (!token) {
    return null;
  }
  const data = await readData();
  const session = data.sessions.find((item) => item.token === token);
  if (!session) {
    return null;
  }
  const user = data.users.find((item) => item.id === session.userId);
  if (!user) {
    return null;
  }
  return {
    session,
    user,
  };
}

async function clearSession(token) {
  if (!token) {
    return;
  }
  await updateData((data) => {
    data.sessions = data.sessions.filter((session) => session.token !== token);
    return data;
  });
}

module.exports = {
  registerEmailAccount,
  loginEmailAccount,
  createGuestSession,
  resolveSession,
  clearSession,
  sanitizeUser,
};
