const { updateData } = require("../storage/data-store");
const { sanitizeUser } = require("./auth-service");

async function saveUserState(userId, nextState) {
  const now = new Date().toISOString();
  const updated = await updateData((data) => {
    const user = data.users.find((item) => item.id === userId);
    if (!user) {
      throw new Error("USER_NOT_FOUND");
    }
    user.appState = nextState;
    user.updatedAt = now;
    return data;
  });

  const user = updated.users.find((item) => item.id === userId);
  return {
    user: sanitizeUser(user),
    state: user.appState,
  };
}

module.exports = {
  saveUserState,
};
