const http = require("http");
const fs = require("fs");
const path = require("path");
const { URL } = require("url");
const { handleApiRequest } = require("../api");

const PORT = Number(process.env.PORT || 4000);
const FRONTEND_DIR = path.resolve(__dirname, "..", "frontend");

const MIME_TYPES = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".png": "image/png",
  ".svg": "image/svg+xml",
  ".ico": "image/x-icon",
};

function sendJson(response, statusCode, payload) {
  response.writeHead(statusCode, { "Content-Type": "application/json; charset=utf-8" });
  response.end(JSON.stringify(payload));
}

function setCorsHeaders(request, response) {
  const origin = request.headers.origin || "*";
  response.setHeader("Access-Control-Allow-Origin", origin);
  response.setHeader("Vary", "Origin");
  response.setHeader("Access-Control-Allow-Methods", "GET,POST,PUT,OPTIONS");
  response.setHeader("Access-Control-Allow-Headers", "Content-Type, x-session-token");
}

function serveStaticFile(response, filePath) {
  fs.readFile(filePath, (error, content) => {
    if (error) {
      sendJson(response, 404, { error: "File not found" });
      return;
    }

    const ext = path.extname(filePath).toLowerCase();
    const isFrontendAsset = [".html", ".css", ".js"].includes(ext);
    response.writeHead(200, {
      "Content-Type": MIME_TYPES[ext] || "application/octet-stream",
      "Cache-Control": isFrontendAsset ? "no-store, must-revalidate" : "public, max-age=3600",
    });
    response.end(content);
  });
}

function resolveFrontendPath(urlPath) {
  const requestedPath = urlPath === "/" ? "/index.html" : urlPath;
  const safePath = path.normalize(requestedPath).replace(/^(\.\.[\\/])+/, "");
  const fullPath = path.join(FRONTEND_DIR, safePath);

  if (!fullPath.startsWith(FRONTEND_DIR)) {
    return null;
  }

  if (fs.existsSync(fullPath) && fs.statSync(fullPath).isFile()) {
    return fullPath;
  }

  return path.join(FRONTEND_DIR, "index.html");
}

const server = http.createServer(async (request, response) => {
  setCorsHeaders(request, response);

  if (request.method === "OPTIONS") {
    response.writeHead(204);
    response.end();
    return;
  }

  const requestUrl = new URL(request.url, `http://${request.headers.host}`);

  if (requestUrl.pathname.startsWith("/api/")) {
    try {
      const handled = await handleApiRequest(request, response, requestUrl);
      if (!handled) {
        sendJson(response, 404, { error: "API route not found" });
      }
    } catch (error) {
      sendJson(response, 500, { error: "Internal server error", detail: error.message });
    }
    return;
  }

  const filePath = resolveFrontendPath(requestUrl.pathname);
  if (!filePath) {
    sendJson(response, 403, { error: "Forbidden" });
    return;
  }

  serveStaticFile(response, filePath);
});

server.listen(PORT, () => {
  console.log(`Heart Jar server running at http://localhost:${PORT}`);
});
